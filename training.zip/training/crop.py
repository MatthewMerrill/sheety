from os import listdir

for f in listdir('training/clean'):
    print(f)

