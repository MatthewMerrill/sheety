from os import listdir
import numpy as np
from subprocess import call

with open('durations.csv', "w") as csv:
    for f in listdir('training/mattchunks/'):
        name = 'training/mattchunks/%s' % f
        dig = int(f[5:-4])
        csv.write('%s,%d\n' % (name, dig // 11));

with open('pitches.csv', "w") as csv:
    for f in listdir('training/mattchunks/'):
        name = 'training/mattchunks/%s' % f
        dig = int(f[5:-4])
        call(["convert", name, ""])
        csv.write('%s,%d\n' % (name, dig % 11));

